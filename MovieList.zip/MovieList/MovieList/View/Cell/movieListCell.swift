//
//  movieListCell.swift
//  MovieList
//
//  Created by Shamim Rayhan on 30/10/21.
//

import UIKit
import SkeletonView
import SDWebImage

class movieListCell: UITableViewCell {

    @IBOutlet weak var movieTitle: UILabel!
    @IBOutlet weak var descriptionLabel: UILabel!
    @IBOutlet weak var posterImageView: UIImageView!
    
    var thumbCategoryThumbUrl : URL?{
            didSet{
                guard let imageURL  = self.thumbCategoryThumbUrl else { return }
                
                
                
                SDImageCache.shared.diskImageExists(withKey: imageURL.absoluteString) { [self] exists in
                    if exists {
                        
                        // return
                    }else{
                        let gradient = SkeletonGradient(baseColor: UIColor(red: 34.0/255.0, green: 34.0/255.0, blue: 64.0/255.0, alpha: 1.0))
                        let animation = SkeletonAnimationBuilder().makeSlidingAnimation(withDirection: .bottomRightTopLeft)
                        posterImageView.showAnimatedGradientSkeleton(usingGradient: gradient, animation: animation)
                        
                    }
                }
                
                
                
                //activityIndicator.startAnimating()
                posterImageView.sd_setImage(with: imageURL  ) { [weak self] (image, error, cache, url) in
                    
                    if error == nil && image != nil {
                        
                        self?.posterImageView.hideSkeleton()
                        //cellSmall.activityIndicator.stopAnimating()
                        
                    }
                    else{
                        print(error!.localizedDescription)
                    }
                }
            }
        }
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
