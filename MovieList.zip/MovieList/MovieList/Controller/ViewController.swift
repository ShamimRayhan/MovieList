//
//  ViewController.swift
//  MovieList
//
//  Created by Shamim Rayhan on 30/10/21.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
    }


}

