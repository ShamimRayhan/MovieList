//
//  MovieListVC.swift
//  MovieList
//
//  Created by Shamim Rayhan on 30/10/21.
//

import UIKit
import DataCache
import SkeletonView


class MovieListVC: UIViewController {
    let ApiManager = RestManager()
    
    @IBOutlet weak var searchResultView: UIView!
    var searchActive : Bool = false
   
    var searchText = ""
    var filtered:[Result] = []
    var movies = [Result]()
    
    @IBOutlet weak var loadingImageView: UIImageView!
    
    
    @IBOutlet weak var searchBar: UISearchBar!{
        didSet{
            searchBar.backgroundImage = UIImage()
            searchBar.delegate = self
        }
    }
    
    @IBOutlet weak var movieListTableView: UITableView!{
        didSet{
            
            
            movieListTableView.delegate = self
            movieListTableView.dataSource = self
            
            movieListTableView.register(UINib(nibName: "movieListCell", bundle: nil), forCellReuseIdentifier: "movieListCell")
            movieListTableView.tableFooterView = UIView()
            
            movieListTableView.contentInset = UIEdgeInsets(top: 0, left: 0, bottom: 36, right: 0)
           
            
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        uiSetup()
        
        
    }
    
    func uiSetup(){
        let gradient = SkeletonGradient(baseColor: UIColor(red: 34.0/255.0, green: 34.0/255.0, blue: 64.0/255.0, alpha: 1.0))
        let animation = SkeletonAnimationBuilder().makeSlidingAnimation(withDirection: .bottomRightTopLeft)
        loadingImageView.showAnimatedGradientSkeleton(usingGradient: gradient, animation: animation)
        loadingImageView.isSkeletonable = true
        let url = "https://api.themoviedb.org/3/search/movie?api_key=38e61227f85671163c275f9bd95a8803&query=marvel"
        getMovieList(urlString: url){success in
            DispatchQueue.main.async { [self] in
                loadingImageView.isSkeletonable = true
                DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
                    loadingImageView.hideSkeleton()
                }
            }
        }
    }
    
    
    
    func getMovieList(urlString: String, completion: @escaping((Bool) -> Void)) {
        
        
        do {
            var Movies: MovieList? = try DataCache.instance.readCodable(forKey: urlString)

            
            if let allMovies = Movies?.results{
                
                movies = allMovies ?? []
                
            }
            DispatchQueue.main.async {
                self.movieListTableView.reloadData()
            }
        } catch {
            print("Read error \(error.localizedDescription)")
        }
        
        
        guard let url = URL(string: urlString) else { return }

//        let userPasswordString = "\(RestManager.Constants.UserName):\(RestManager.Constants.Paswword)"
//        let userPasswordData = userPasswordString.data(using: String.Encoding.utf8)
//        let base64EncodedCredential = userPasswordData!.base64EncodedString(options: [])
//        let authString = "Basic \(base64EncodedCredential)"
        
       // rest.requestHttpHeaders.add(value: authString, forKey: "Authorization")
        ApiManager.makeRequest(toURL: url, withHttpMethod: .get) { [self] (results) in
                
                if let error = results.error {
                    print(error.localizedDescription)
                    return
                }
                if let data = results.data {
                    
                    print(data)
                    
                    let decoder = JSONDecoder()
                    
                    guard let collections = try? decoder.decode(MovieList.self, from: data) else {return }
                    
                    do {
                        try DataCache.instance.write(codable: collections, forKey: urlString)
                    } catch {
                        print("Write error \(error.localizedDescription)")
                    }
                    
                    if let data = collections.results{
                        movies = data
                        completion(true)
                        
                    }
                    DispatchQueue.main.async {
                        movieListTableView.reloadData()
                        
                    }
                    
                }
                else {
                    
                }

            }
        }
    

    

}


extension MovieListVC : UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if(searchActive) {
            if(filtered.count == 0){
                searchResultView.alpha = 1.0
            }
            return filtered.count
        }
        
        return movies.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = movieListTableView.dequeueReusableCell(withIdentifier: "movieListCell") as! movieListCell
        
        
        if(searchActive && filtered.count > indexPath.row) {
            let movie = filtered[indexPath.row]
            
            cell.posterImageView.isSkeletonable = true
            
            if movies.count > indexPath.row, let apiEndPoint = movie.posterPath{
                
                
                
                
                
                let stickerUrl = URL(string: "https://image.tmdb.org/t/p/w500\(apiEndPoint)")
                
                
                cell.thumbCategoryThumbUrl = stickerUrl
                cell.movieTitle.text = movie.title
                cell.descriptionLabel.text = movie.overview
                
            }
            return cell
        }
        
        
        
        
        let movie = movies[indexPath.row]
        
        
        
        
        
        
        
        cell.posterImageView.isSkeletonable = true
        
        if movies.count > indexPath.row, let apiEndPoint = movies[indexPath.row].posterPath{
            
            
            
            
            
            let stickerUrl = URL(string: "https://image.tmdb.org/t/p/w500\(apiEndPoint)")
            
            
            cell.thumbCategoryThumbUrl = stickerUrl
            cell.movieTitle.text = movie.title
            cell.descriptionLabel.text = movie.overview
            
        }
        
        
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200.0
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        
    }

}


extension MovieListVC: UISearchBarDelegate{
    
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {

        self.searchBar.setShowsCancelButton(true, animated: true)
        
    }

    
    func searchBarTextDidEndEditing(_ searchBar: UISearchBar) {

        
        self.searchBar.setShowsCancelButton(false, animated: true)
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        self.searchBar.setShowsCancelButton(false, animated: true)
        searchActive = false
        searchBar.text = nil
        searchResultView.alpha = 0.0
        filtered = movies
        self.searchBar.endEditing(true)
        print("filtered  \(self.filtered.count)")
        movieListTableView.reloadData()
        
        
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        self.searchBar.setShowsCancelButton(true, animated: true)
        searchActive = false
        self.searchBar.endEditing(true)
        if(searchBar.text == ""){
            searchResultView.alpha = 0.0
        }
        
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {

        self.searchBar.text = searchText
        self.updateSearchResult()
    }
    
    
    func updateSearchResult() {
        
        if let srchTxt = searchBar.text {
            
            self.searchText = srchTxt
        }
        
        if(searchBar.text == ""){
            searchResultView.alpha = 0.0
        }

        searchActive = searchText.count > 0 ? true: false
        

        if searchActive {
            filtered = movies.filter { (movie: Result) -> Bool in
                
                return (movie.title?.lowercased().contains(self.searchText.lowercased()) ?? false)
            }
            
        }
        
        
        movieListTableView.reloadData()
        
       
    }
    
}
